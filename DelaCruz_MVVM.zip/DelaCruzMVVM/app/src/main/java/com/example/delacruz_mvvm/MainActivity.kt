package com.example.delacruz_mvvm

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView?>(R.id.recyclerview)

        val items: MutableList<FoodItems?> = ArrayList<FoodItems?>()
        items.add(FoodItems(R.drawable.avocado, "Avocado", "P25"))
        items.add(FoodItems(R.drawable.mango, "Mango", "P20"))
        items.add(FoodItems(R.drawable.apple, "Apple", "P10"))
        items.add(FoodItems(R.drawable.dragonfruit, "Dragon Fruit", "P35"))
        items.add(FoodItems(R.drawable.guava, "Guava", "P30"))
        items.add(FoodItems(R.drawable.durian, "Durian", "P100"))
        items.add(FoodItems(R.drawable.rambutan, "Rambutan", "P40"))


        recyclerView.setLayoutManager(LinearLayoutManager(this))
        recyclerView.setAdapter(FoodAdapter(getApplicationContext(), items))
    }
}